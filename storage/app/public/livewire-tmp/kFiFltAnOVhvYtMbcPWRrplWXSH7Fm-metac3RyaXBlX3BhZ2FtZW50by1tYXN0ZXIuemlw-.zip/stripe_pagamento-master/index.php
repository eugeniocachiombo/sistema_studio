<link rel="stylesheet" href="assets/css/style.css" />

<form action="charge.php" method="post" id="payment-form">
    <div class="form-row">
        <?php require "venda.php"; ?>

        <label for="card-element">Credit or debit card</label>
        <div id="card-element" style="width: 250px"></div>

        <div id="card-errors"></div>
    </div>
</form>

<p>Exemplo de cartºao insira: 4242 4242 4242 4242</p>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://js.stripe.com/v3/"></script>
<script src="assets/js/charge.js"></script>