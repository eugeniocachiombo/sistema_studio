<?php 
require_once('vendor/autoload.php');
$secret_key = "sk_test_51O822uKL4km6mNiGaihsg8vihLZvOSuQCRkGPiqm37wB8YwZnzD6tQJ9BeoZJH6fKKFNy0NWTtqoS5bF2EAz6wLV00qut0E6EI";
\Stripe\Stripe::setApiKey($secret_key);
$token = $_POST['stripeToken'];
$charge = \Stripe\Charge::create(
    array(
        'amount' => 304000,
        'currency' => 'usd',
        'description' => 'exemplo@gmail.com',
        'receipt_email' => 'eugeniocachiombo@gmail.com',
        'source' => $token
    )
);
echo "<pre>";
var_dump($charge);
echo "</pre>";
?>