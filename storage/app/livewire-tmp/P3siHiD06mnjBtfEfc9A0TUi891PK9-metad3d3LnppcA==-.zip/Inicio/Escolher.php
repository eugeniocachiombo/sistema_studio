<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title>Página inicial</title>
	<meta charset="utf-8">
	<style type="text/css">
		
		body{
			background: gray;
			color: black;
			
		}

		#Cabeçario{
			background-size: cover;
			background: #068ccb;
			color: white;
			text-align: center;
		}

		#corpo{
			/*background: #c9d5db;*/
			color: white;
			text-align: center;
		}

		footer{
			background: #068ccb;
			color: white;
		}

		#image{
			width: 20%
		}
	</style>
</head>
<body>
	<div id="Cabeçario">
	
		<br>
	<label>	<a href="../index.php"><img src="../Imagens/2logo.png" id="image"></a>
		<h3> Seja Bem-vindo  <br>
			Pauta dos estudantes da escola Cachiombo
		</h3>
	</label>

	</div>
	
	<div id="corpo">
		<br> <br><br> <br> <br> <br>

		<h3>Em breve serão lançadas as pautas dos alunos neste site</h3>
		<p>Pretende Cadastrar um aluno?</p>
	<a href="../Aluno/FormularioAluno.php">	<input type="button" value="Clique Aqui" > </a>
	<p>Pretende Cadastrar um Professor?</p>
	<a href="../Professor/FormularioProfessor.php">	<input type="button" value= "Clique Aqui" > </a>
	<!--	<img border="2" src="Imagens/2logo.png" id="image"> -->
		 <br> <br> <br> <br><br> <br> 
	</div>
</body>

<footer>
	<dl>
		
		<dt> <h3> Sobre </h3></dt>

		<dd>
			Este site foi criador pelo estudante Eugénio Cachiombo do curso de Engenharia Informática. <br>
			<strong>Localização:</strong> Município do Cazenga, bairro Mabor / Hoji-yá-Henda<br>
			<strong>Contactos:</strong> 921439849 <strong>whatsapp:</strong> 921439849 <strong>Facebook:</strong> Génio Pró Gp
			
			
		</dd>

	</dl>

		 <br>
</footer>
</html>