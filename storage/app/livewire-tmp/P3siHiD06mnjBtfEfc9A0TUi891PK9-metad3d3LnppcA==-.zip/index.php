<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title>Página inicial</title>
	<meta charset="utf-8">
	<style type="text/css">
		
		body{
			background: gray;
			color: white;	
		}

		#Cabeçario{
			background-size: cover;
			background: #068ccb;
			color: white;
			text-align: center;
		}

		#corpo{
			/*background: #c9d5db;*/
			color: white;
			text-align: center;
		}

		footer{
			background: #068ccb;
			color: white;
		}

		#image{
			width: 20%
		}
	</style>
</head>
<body>




	<div id="Cabeçario">
	
		<br>
	<label>	<img src="Imagens/2logo.png" id="image">
		<h3> Seja Bem-vindo  <br>
			Pauta dos estudantes da escola Cachiombo
		</h3>
	</label>
	
	</div>
		



	<div id="corpo">
		<br> <br><br> <br> <br> <br>
		<p>Pretende ver Pauta?</p>
		<a href="Inicio/Verpauta.php" style="color: white;"><p>Clique Aqui</p> </a>
		<br> <br>
		<a href="Inicio/Login.php"><input type="button" value="Iniciar Sessão"></a> 
		<p>Pretende fazer um cadastro?</p>
	<a href="Inicio/Escolher.php" style="color: white;">	<p>Clique Aqui</p> </a>
	<!--	<img border="2" src="Imagens/2logo.png" id="image"> -->
		 <br> <br> <br> <br><br> <br> 
	</div>
</body>

<footer>
	<dl>
		
		<dt> <h3> Sobre </h3></dt>

		<dd>
			Este site foi criador pelo estudante Eugénio Cachiombo do curso de Engenharia Informática. <br>
			<strong>Localização:</strong> Município do Cazenga, bairro Mabor / Hoji-yá-Henda<br>
			<strong>Contactos:</strong> 921439849 <strong>whatsapp:</strong> 921439849 <strong>Facebook:</strong> Génio Pró Gp
			
			
		</dd>

	</dl>

		 <br>
</footer>
</html>